import { FaArrowRightLong, FaArrowLeftLong } from "react-icons/fa6";
import { useState } from "react";

function App() {
  const [showAll, setShowAll] = useState(true);

  const data = [
    { id: 1, name: "Sarthak", email: "sarthak@email.com", password: "1234" },
    { id: 2, name: "Raj", email: "raj@email.com", password: "5678" },
    { id: 3, name: "Meera", email: "meera@email.com", password: "abcd" }
  ];

  let rowsToShow = [];
  if (showAll) {
    rowsToShow = data;
  } else {
    rowsToShow = [data[0]];
  }

  let arrowIcon;
  if (showAll) {
    arrowIcon = <FaArrowRightLong />;
  } else {
    arrowIcon = <FaArrowLeftLong />;
  }

  const toggleRows = () => {
    if (showAll == true) {
      setShowAll(false);
    } else {
      setShowAll(true);
    }
  };

  return (
    <div align="center">
      <h1 style={{ fontWeight: "bold", fontSize: "2rem", display: "flex", alignItems: "center", justifyContent: "center", gap: "10px" }}>
        table
        <span
          style={{ display: "flex", alignItems: "center", cursor: "pointer" }}
          onClick={toggleRows}>
          {arrowIcon}
        </span>
      </h1>

      <table border={1} cellPadding={10} cellSpacing={0}>
        <thead>
          <tr>
            <th>id</th>
            <th>name</th>
            <th>email</th>
            <th>password</th>
          </tr>
        </thead>
        <tbody>
          {
            rowsToShow.map((item) => (
              <tr key={item.id}>
                <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.email}</td>
                <td>{item.password}</td>
              </tr>
            ))
          }
        </tbody>
      </table>
    </div>
  );
}

export default App;