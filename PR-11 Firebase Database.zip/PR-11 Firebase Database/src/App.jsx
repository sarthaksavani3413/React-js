import Add from "./pages/Add"

function App() {

  return (
    <>
    <Add/>
    </>
  )
}

export default App
